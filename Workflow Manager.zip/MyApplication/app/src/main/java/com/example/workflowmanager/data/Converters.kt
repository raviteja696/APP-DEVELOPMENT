package com.example.workflowmanager.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromStatus(value: TaskStatus): String = value.name

    @TypeConverter
    fun toStatus(value: String): TaskStatus = TaskStatus.valueOf(value)
}


