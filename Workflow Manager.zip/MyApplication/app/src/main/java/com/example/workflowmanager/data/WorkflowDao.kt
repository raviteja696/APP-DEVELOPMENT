package com.example.workflowmanager.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface WorkflowDao {
    // Projects
    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun observeProjects(): LiveData<List<ProjectEntity>>

    @Insert
    suspend fun insertProject(project: ProjectEntity): Long

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    // Tasks
    @Query("SELECT * FROM tasks WHERE projectId = :projectId ORDER BY id DESC")
    fun observeTasks(projectId: Long): LiveData<List<TaskEntity>>

    @Insert
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE projectId = :projectId")
    suspend fun deleteTasksForProject(projectId: Long)

    @Transaction
    suspend fun deleteProjectCascading(project: ProjectEntity) {
        deleteTasksForProject(project.id)
        deleteProject(project)
    }
}


