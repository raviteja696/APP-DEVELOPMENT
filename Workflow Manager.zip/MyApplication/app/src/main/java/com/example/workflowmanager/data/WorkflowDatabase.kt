package com.example.workflowmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [ProjectEntity::class, TaskEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class WorkflowDatabase : RoomDatabase() {
    abstract fun dao(): WorkflowDao

    companion object {
        @Volatile private var INSTANCE: WorkflowDatabase? = null

        fun get(context: Context): WorkflowDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
        }

        private fun buildDatabase(context: Context): WorkflowDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                WorkflowDatabase::class.java,
                "workflow-db"
            ).addCallback(object : Callback() {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)
                    // Prepopulate with demo data
                    val appContext = context.applicationContext
                    CoroutineScope(Dispatchers.IO).launch {
                        val database = get(appContext)
                        val dao = database.dao()
                        val now = System.currentTimeMillis()
                        val projectId = dao.insertProject(
                            ProjectEntity(name = "Demo Project", description = "Sample project to get started", createdAt = now)
                        )
                        dao.insertTask(TaskEntity(projectId = projectId, title = "Setup repo", description = "Initialize git repository", status = TaskStatus.COMPLETED))
                        dao.insertTask(TaskEntity(projectId = projectId, title = "Design schema", description = "Plan Room entities and relations", status = TaskStatus.IN_PROGRESS))
                        dao.insertTask(TaskEntity(projectId = projectId, title = "Build UI", description = "Create list and details screens", status = TaskStatus.TO_DO))
                    }
                }
            }).build()
        }
    }
}


