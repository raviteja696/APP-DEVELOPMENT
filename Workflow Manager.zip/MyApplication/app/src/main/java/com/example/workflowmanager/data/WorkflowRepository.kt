package com.example.workflowmanager.data

import android.content.Context

class WorkflowRepository private constructor(private val dao: WorkflowDao) {

    fun observeProjects() = dao.observeProjects()

    fun observeTasks(projectId: Long) = dao.observeTasks(projectId)

    suspend fun addProject(name: String, description: String): Long {
        return dao.insertProject(
            ProjectEntity(
                name = name,
                description = description,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun addTask(projectId: Long, title: String, description: String, status: TaskStatus): Long {
        return dao.insertTask(TaskEntity(projectId = projectId, title = title, description = description, status = status))
    }

    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)

    companion object {
        @Volatile private var INSTANCE: WorkflowRepository? = null

        fun get(context: Context): WorkflowRepository = INSTANCE ?: synchronized(this) {
            val db = WorkflowDatabase.get(context)
            INSTANCE ?: WorkflowRepository(db.dao()).also { INSTANCE = it }
        }
    }
}


