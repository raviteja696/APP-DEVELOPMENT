package com.example.workflowmanager.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.workflowmanager.R
import com.example.workflowmanager.data.TaskEntity
import com.example.workflowmanager.data.TaskStatus
import com.example.workflowmanager.databinding.FragmentProjectDetailsBinding

class ProjectDetailsFragment : Fragment() {
    private var _binding: FragmentProjectDetailsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ProjectDetailsViewModel by viewModels()
    private lateinit var adapter: TaskListAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentProjectDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val projectId = requireArguments().getLong("projectId")
        viewModel.setProjectId(projectId)

        adapter = TaskListAdapter(
            onStatusChanged = { task, status -> viewModel.updateTask(task.copy(status = status)) }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener {
            viewModel.addTask("New Task", "Description", TaskStatus.TO_DO)
        }

        viewModel.tasks.observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            updateStats(list)
        }
    }

    private fun updateStats(list: List<TaskEntity>) {
        val total = list.size
        val completed = list.count { it.status == TaskStatus.COMPLETED }
        val percent = if (total == 0) 0 else (completed * 100 / total)
        binding.progressBar.progress = percent
        binding.txtStats.text = getString(R.string.stats_format, total, list.count { it.status == TaskStatus.TO_DO }, list.count { it.status == TaskStatus.IN_PROGRESS }, completed)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}


