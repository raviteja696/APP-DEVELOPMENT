package com.example.workflowmanager.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.example.workflowmanager.data.TaskEntity
import com.example.workflowmanager.data.TaskStatus
import com.example.workflowmanager.data.WorkflowRepository
import kotlinx.coroutines.launch

class ProjectDetailsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = WorkflowRepository.get(application)

    private val _projectId = MutableLiveData<Long>()
    val projectId: LiveData<Long> = _projectId

    val tasks: LiveData<List<TaskEntity>> = _projectId.switchMap { id ->
        repository.observeTasks(id)
    }

    fun setProjectId(id: Long) { _projectId.value = id }

    fun addTask(title: String, description: String, status: TaskStatus) {
        val id = _projectId.value ?: return
        viewModelScope.launch { repository.addTask(id, title, description, status) }
    }

    fun updateTask(task: TaskEntity) {
        viewModelScope.launch { repository.updateTask(task) }
    }
}


