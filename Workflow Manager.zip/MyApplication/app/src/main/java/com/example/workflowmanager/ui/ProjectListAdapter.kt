package com.example.workflowmanager.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.workflowmanager.data.ProjectEntity
import com.example.workflowmanager.databinding.ItemProjectBinding

class ProjectListAdapter(
    private val onClick: (ProjectEntity) -> Unit
) : ListAdapter<ProjectEntity, ProjectListAdapter.ProjectViewHolder>(Diff) {

    object Diff : DiffUtil.ItemCallback<ProjectEntity>() {
        override fun areItemsTheSame(oldItem: ProjectEntity, newItem: ProjectEntity) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: ProjectEntity, newItem: ProjectEntity) = oldItem == newItem
    }

    inner class ProjectViewHolder(private val binding: ItemProjectBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ProjectEntity) {
            binding.title.text = item.name
            binding.description.text = item.description
            binding.root.setOnClickListener { onClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProjectViewHolder {
        val binding = ItemProjectBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProjectViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProjectViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}


