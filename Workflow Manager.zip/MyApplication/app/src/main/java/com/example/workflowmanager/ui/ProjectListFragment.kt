package com.example.workflowmanager.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.workflowmanager.R
import com.example.workflowmanager.databinding.FragmentProjectListBinding

class ProjectListFragment : Fragment() {
    private var _binding: FragmentProjectListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ProjectListViewModel by viewModels()
    private lateinit var adapter: ProjectListAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentProjectListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = ProjectListAdapter { project ->
            val action = R.id.action_projectListFragment_to_projectDetailsFragment
            findNavController().navigate(action, Bundle().apply { putLong("projectId", project.id) })
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener {
            viewModel.addProject("New Project", "Description")
        }

        viewModel.projects.observe(viewLifecycleOwner) { list -> adapter.submitList(list) }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}


