package com.example.workflowmanager.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.workflowmanager.data.ProjectEntity
import com.example.workflowmanager.data.WorkflowRepository
import kotlinx.coroutines.launch

class ProjectListViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = WorkflowRepository.get(application)

    val projects: LiveData<List<ProjectEntity>> = repository.observeProjects()

    fun addProject(name: String, description: String) {
        viewModelScope.launch { repository.addProject(name, description) }
    }
}


