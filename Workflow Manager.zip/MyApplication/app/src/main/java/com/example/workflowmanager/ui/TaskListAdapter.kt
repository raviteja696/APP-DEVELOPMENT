package com.example.workflowmanager.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.workflowmanager.data.TaskEntity
import com.example.workflowmanager.data.TaskStatus
import com.example.workflowmanager.databinding.ItemTaskBinding

class TaskListAdapter(
    private val onStatusChanged: (TaskEntity, TaskStatus) -> Unit
) : ListAdapter<TaskEntity, TaskListAdapter.TaskViewHolder>(Diff) {

    object Diff : DiffUtil.ItemCallback<TaskEntity>() {
        override fun areItemsTheSame(oldItem: TaskEntity, newItem: TaskEntity) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: TaskEntity, newItem: TaskEntity) = oldItem == newItem
    }

    inner class TaskViewHolder(private val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: TaskEntity) {
            binding.title.text = item.title
            binding.description.text = item.description

            val statuses = TaskStatus.values().map { it.name.replace('_', ' ') }
            val adapter = ArrayAdapter(binding.root.context, android.R.layout.simple_spinner_item, statuses).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            binding.spinner.adapter = adapter
            binding.spinner.setSelection(item.status.ordinal)
            binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                    val newStatus = TaskStatus.values()[position]
                    if (newStatus != item.status) onStatusChanged(item, newStatus)
                }
                override fun onNothingSelected(parent: AdapterView<*>) {}
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}


